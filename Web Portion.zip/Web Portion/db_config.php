<?php

/*
 * All database connection variables
 */

define('DB_USER', "a8535088_karee"); // db user
define('DB_PASSWORD', "k799747"); // db password (mention your db password here)
define('DB_DATABASE', "a8535088_admin"); // database name
define('DB_SERVER', "mysql13.000webhost.com"); // db server
?>